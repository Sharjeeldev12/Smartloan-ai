import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

class FinancialFeatureTransformer(BaseEstimator, TransformerMixin):
    """
    Scikit-Learn compatible custom transformer for financial feature engineering:
    - Calculates Total Income
    - Calculates Monthly EMI & Balance Income
    - Computes Debt-to-Income (DTI) ratio
    - Categorizes Credit Score into tiers
    - Applies Log transformations for skewed features
    """

    def __init__(self):
        pass

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()

        # Fill potential NaNs in input prior to mathematical operations
        applicant_inc = df["ApplicantIncome"].fillna(df["ApplicantIncome"].median() if len(df) > 0 else 3000)
        coapplicant_inc = df["CoapplicantIncome"].fillna(0)
        loan_amt = df["LoanAmount"].fillna(df["LoanAmount"].median() if len(df) > 0 else 150)
        loan_term = df["Loan_Amount_Term"].fillna(360)
        credit_score = df["Credit_Score"].fillna(650)

        # 1. Total Income
        df["Total_Income"] = applicant_inc + coapplicant_inc

        # 2. Debt-to-Income (DTI) ratio (Loan amount in thousands vs annual income)
        df["Debt_to_Income_Ratio"] = (loan_amt * 1000) / (df["Total_Income"] + 1e-5)

        # 3. Monthly EMI & Remaining Balance Income
        df["Monthly_EMI"] = (loan_amt * 1000) / (loan_term + 1e-5)
        df["Balance_Income"] = (df["Total_Income"] / 12) - df["Monthly_EMI"]

        # 4. Credit Score Tier
        def get_credit_tier(score):
            if score < 580:
                return "Poor"
            elif score < 670:
                return "Fair"
            elif score < 740:
                return "Good"
            else:
                return "Excellent"

        df["Credit_Tier"] = credit_score.apply(get_credit_tier)

        # 5. Log Transformations
        df["Log_Total_Income"] = np.log1p(df["Total_Income"])
        df["Log_LoanAmount"] = np.log1p(loan_amt)

        return df


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Helper function to apply financial feature engineering to a DataFrame.
    """
    transformer = FinancialFeatureTransformer()
    return transformer.transform(df)


if __name__ == "__main__":
    from src.data_loader import generate_raw_loan_dataset
    raw = generate_raw_loan_dataset(5)
    transformed = add_engineered_features(raw)
    print("Engineered Columns:", transformed.columns.tolist())
    print(transformed[["ApplicantIncome", "Total_Income", "Debt_to_Income_Ratio", "Credit_Tier"]].head())
