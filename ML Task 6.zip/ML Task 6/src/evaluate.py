import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, log_loss, confusion_matrix, roc_curve
)

def evaluate_model_pipeline(pipeline, X_test, y_test, reports_dir: str = "reports"):
    """
    Evaluates trained pipeline on test dataset, computes metrics, and generates visual plots.
    """
    os.makedirs(reports_dir, exist_ok=True)

    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)[:, 1]

    # Calculate Metrics
    acc = float(accuracy_score(y_test, y_pred))
    prec = float(precision_score(y_test, y_pred))
    rec = float(recall_score(y_test, y_pred))
    f1 = float(f1_score(y_test, y_pred))
    auc = float(roc_auc_score(y_test, y_prob))
    loss = float(log_loss(y_test, y_prob))

    metrics = {
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_score": round(f1, 4),
        "roc_auc": round(auc, 4),
        "log_loss": round(loss, 4)
    }

    print("\n--- Test Set Evaluation Results ---")
    for k, v in metrics.items():
        print(f"{k.capitalize()}: {v}")

    # Save Metrics JSON
    metrics_path = os.path.join(reports_dir, "metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=4)
    print(f"Saved metrics JSON to {metrics_path}")

    # 1. Confusion Matrix Plot
    plt.figure(figsize=(6, 5))
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False,
                xticklabels=["Rejected (0)", "Approved (1)"],
                yticklabels=["Rejected (0)", "Approved (1)"])
    plt.title("Loan Approval Confusion Matrix", fontsize=12, fontweight="bold")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.tight_layout()
    cm_path = os.path.join(reports_dir, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=300)
    plt.close()
    print(f"Saved confusion matrix plot to {cm_path}")

    # 2. ROC Curve Plot
    plt.figure(figsize=(7, 5))
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    plt.plot(fpr, tpr, color="#2563eb", lw=2.5, label=f"ROC Curve (AUC = {auc:.4f})")
    plt.plot([0, 1], [0, 1], color="#94a3b8", linestyle="--", lw=1.5)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Receiver Operating Characteristic (ROC) Curve", fontsize=12, fontweight="bold")
    plt.legend(loc="lower right")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    roc_path = os.path.join(reports_dir, "roc_curve.png")
    plt.savefig(roc_path, dpi=300)
    plt.close()
    print(f"Saved ROC curve plot to {roc_path}")

    # 3. Feature Importance Plot
    try:
        classifier = pipeline.named_steps["classifier"]
        preprocessor = pipeline.named_steps["preprocessor"]

        # Extract feature names after OneHotEncoding
        cat_onehot_features = list(preprocessor.named_transformers_["cat"].named_steps["onehot"].get_feature_names_out())
        num_features = pipeline.named_steps["preprocessor"].transformers[0][2]
        feature_names = num_features + cat_onehot_features

        importances = None
        if hasattr(classifier, "feature_importances_"):
            importances = classifier.feature_importances_
        elif hasattr(classifier, "coef_"):
            importances = np.abs(classifier.coef_[0])

        if importances is not None and len(importances) == len(feature_names):
            feat_imp = pd.Series(importances, index=feature_names).sort_values(ascending=False).head(15)

            plt.figure(figsize=(9, 6))
            sns.barplot(x=feat_imp.values, y=feat_imp.index, palette="viridis")
            plt.title("Top 15 Feature Importances", fontsize=12, fontweight="bold")
            plt.xlabel("Relative Importance Score")
            plt.tight_layout()
            feat_path = os.path.join(reports_dir, "feature_importance.png")
            plt.savefig(feat_path, dpi=300)
            plt.close()
            print(f"Saved feature importance plot to {feat_path}")
    except Exception as e:
        print(f"Feature importance plotting skipped: {e}")

    return metrics


if __name__ == "__main__":
    import joblib
    from src.train import train_and_evaluate_models
    pipeline, X_tr, X_te, y_tr, y_te, meta = train_and_evaluate_models()
    evaluate_model_pipeline(pipeline, X_te, y_te)
