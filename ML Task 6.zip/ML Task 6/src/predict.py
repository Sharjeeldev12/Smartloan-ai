import os
import joblib
import pandas as pd
from typing import Dict, Any, List, Union

class LoanPredictor:
    """
    Inference Engine Wrapper for SmartLoan AI.
    Loads serialized joblib model pipeline and executes single or batch predictions.
    """

    def __init__(self, model_path: str = "models/best_loan_model.joblib"):
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model artifact not found at {model_path}. Train the model first.")
        self.model_path = model_path
        self.pipeline = joblib.load(model_path)

    def predict_single(self, applicant_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes prediction for a single applicant dictionary.
        Returns prediction decision, approval status, probability, and risk level.
        """
        df = pd.DataFrame([applicant_data])
        prediction = int(self.pipeline.predict(df)[0])
        probability = float(self.pipeline.predict_proba(df)[0, 1])

        status = "APPROVED" if prediction == 1 else "REJECTED"
        
        # Risk assessment breakdown
        if probability >= 0.75:
            risk_level = "LOW RISK"
        elif probability >= 0.50:
            risk_level = "MODERATE RISK"
        elif probability >= 0.30:
            risk_level = "HIGH RISK"
        else:
            risk_level = "VERY HIGH RISK"

        return {
            "prediction": prediction,
            "status": status,
            "approval_probability": round(probability, 4),
            "risk_level": risk_level
        }

    def predict_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Executes predictions for a batch DataFrame of loan applicants.
        Appends 'Predicted_Status', 'Approval_Probability', and 'Risk_Level' columns.
        """
        df_result = df.copy()
        predictions = self.pipeline.predict(df_result)
        probabilities = self.pipeline.predict_proba(df_result)[:, 1]

        df_result["Predicted_Status"] = ["APPROVED" if p == 1 else "REJECTED" for p in predictions]
        df_result["Approval_Probability"] = probabilities.round(4)
        
        def get_risk(prob):
            if prob >= 0.75:
                return "LOW RISK"
            elif prob >= 0.50:
                return "MODERATE RISK"
            elif prob >= 0.30:
                return "HIGH RISK"
            else:
                return "VERY HIGH RISK"

        df_result["Risk_Level"] = [get_risk(p) for p in probabilities]
        return df_result


if __name__ == "__main__":
    predictor = LoanPredictor()
    sample_applicant = {
        "Gender": "Male",
        "Married": "Yes",
        "Dependents": "1",
        "Education": "Graduate",
        "Self_Employed": "No",
        "ApplicantIncome": 6000,
        "CoapplicantIncome": 2500,
        "LoanAmount": 150,
        "Loan_Amount_Term": 360,
        "Credit_History": 1.0,
        "Credit_Score": 720,
        "Property_Area": "Semiurban"
    }
    result = predictor.predict_single(sample_applicant)
    print("Sample Applicant Prediction:", result)
