import os
import json
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

try:
    from xgboost import XGBClassifier
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

from src.data_loader import load_and_save_data
from src.feature_engineering import FinancialFeatureTransformer

def build_preprocessing_pipeline():
    """
    Creates Scikit-Learn ColumnTransformer for numerical scaling and categorical encoding.
    """
    num_features = [
        "ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term",
        "Credit_History", "Credit_Score", "Total_Income", "Debt_to_Income_Ratio",
        "Monthly_EMI", "Balance_Income", "Log_Total_Income", "Log_LoanAmount"
    ]
    
    cat_features = [
        "Gender", "Married", "Dependents", "Education",
        "Self_Employed", "Property_Area", "Credit_Tier"
    ]

    num_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    cat_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", num_transformer, num_features),
            ("cat", cat_transformer, cat_features)
        ]
    )

    return preprocessor, num_features, cat_features


def train_and_evaluate_models(data_path: str = "data/processed/cleaned_loan_data.csv",
                              model_save_path: str = "models/best_loan_model.joblib",
                              metadata_save_path: str = "models/model_metadata.json"):
    """
    Executes full ML training pipeline:
    1. Loads cleaned dataset
    2. Applies feature engineering & train-test split
    3. Benchmarks multiple classifiers with Stratified CV
    4. Performs hyperparameter tuning on best candidate
    5. Serializes trained pipeline and saves metadata JSON
    """
    os.makedirs("models", exist_ok=True)

    if not os.path.exists(data_path):
        df = load_and_save_data()
    else:
        df = pd.read_csv(data_path)

    # Encode target variable: Y -> 1, N -> 0
    df["Target"] = df["Loan_Status"].map({"Y": 1, "N": 0})
    df_clean = df.dropna(subset=["Target"]).copy()

    X = df_clean.drop(columns=["Loan_ID", "Loan_Status", "Target"])
    y = df_clean["Target"]

    # Stratified Train-Test Split (80% Train, 20% Test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"Data split completed: Train shape {X_train.shape}, Test shape {X_test.shape}")

    # Build preprocessing column transformer
    preprocessor, num_cols, cat_cols = build_preprocessing_pipeline()

    # Define model candidate pool
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42)
    }

    if HAS_XGBOOST:
        models["XGBoost"] = XGBClassifier(eval_metric="logloss", random_state=42)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    model_cv_scores = {}

    print("\n--- Model Candidate Cross-Validation ---")
    best_model_name = None
    best_cv_score = -1.0

    for name, clf in models.items():
        pipeline = Pipeline(steps=[
            ("feature_engineering", FinancialFeatureTransformer()),
            ("preprocessor", preprocessor),
            ("classifier", clf)
        ])

        scores = cross_val_score(pipeline, X_train, y_train, cv=cv, scoring="roc_auc")
        mean_score = float(np.mean(scores))
        std_score = float(np.std(scores))
        model_cv_scores[name] = {"roc_auc_mean": mean_score, "roc_auc_std": std_score}
        print(f"{name}: ROC-AUC = {mean_score:.4f} (+/- {std_score:.4f})")

        if mean_score > best_cv_score:
            best_cv_score = mean_score
            best_model_name = name

    print(f"\nTop Performing Model Candidate: {best_model_name} (CV ROC-AUC: {best_cv_score:.4f})")

    # Hyperparameter Tuning on Best Model Candidate
    print(f"\nRunning Hyperparameter Tuning (GridSearchCV) for {best_model_name}...")

    if best_model_name == "Random Forest":
        clf_estimator = RandomForestClassifier(random_state=42)
        param_grid = {
            "classifier__n_estimators": [100, 200],
            "classifier__max_depth": [5, 10, None],
            "classifier__min_samples_split": [2, 5]
        }
    elif best_model_name == "Gradient Boosting":
        clf_estimator = GradientBoostingClassifier(random_state=42)
        param_grid = {
            "classifier__n_estimators": [100, 150],
            "classifier__learning_rate": [0.05, 0.1],
            "classifier__max_depth": [3, 5]
        }
    elif HAS_XGBOOST and best_model_name == "XGBoost":
        clf_estimator = XGBClassifier(eval_metric="logloss", random_state=42)
        param_grid = {
            "classifier__n_estimators": [100, 200],
            "classifier__learning_rate": [0.03, 0.1],
            "classifier__max_depth": [3, 5]
        }
    else:
        clf_estimator = LogisticRegression(max_iter=1000, random_state=42)
        param_grid = {
            "classifier__C": [0.1, 1.0, 10.0],
            "classifier__solver": ["lbfgs", "liblinear"]
        }

    full_pipeline = Pipeline(steps=[
        ("feature_engineering", FinancialFeatureTransformer()),
        ("preprocessor", preprocessor),
        ("classifier", clf_estimator)
    ])

    grid_search = GridSearchCV(
        full_pipeline,
        param_grid=param_grid,
        cv=cv,
        scoring="roc_auc",
        n_jobs=-1
    )

    grid_search.fit(X_train, y_train)

    best_pipeline = grid_search.best_estimator_
    best_params = grid_search.best_params_
    print(f"Hyperparameter Tuning Complete. Best Params: {best_params}")

    # Serialize Best Model Pipeline
    joblib.dump(best_pipeline, model_save_path)
    print(f"Successfully saved serialized model pipeline to {model_save_path}")

    # Save Model Metadata JSON
    metadata = {
        "model_name": best_model_name,
        "best_cv_roc_auc": float(grid_search.best_score_),
        "hyperparameters": {k.replace("classifier__", ""): v for k, v in best_params.items()},
        "candidate_cv_scores": model_cv_scores,
        "numerical_features": num_cols,
        "categorical_features": cat_cols,
        "train_samples": len(X_train),
        "test_samples": len(X_test)
    }

    with open(metadata_save_path, "w") as f:
        json.dump(metadata, f, indent=4)

    print(f"Saved model metadata to {metadata_save_path}")

    return best_pipeline, X_train, X_test, y_train, y_test, metadata


if __name__ == "__main__":
    train_and_evaluate_models()
