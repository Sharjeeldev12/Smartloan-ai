import os
import numpy as np
import pandas as pd

def generate_raw_loan_dataset(n_samples: int = 1500, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a realistic loan application dataset with realistic financial distributions,
    demographics, credit histories, and balanced loan approval target flags.
    """
    np.random.seed(random_state)

    loan_ids = [f"LP00{1000 + i}" for i in range(n_samples)]
    genders = np.random.choice(["Male", "Female"], size=n_samples, p=[0.78, 0.22])
    married = np.random.choice(["Yes", "No"], size=n_samples, p=[0.65, 0.35])
    dependents = np.random.choice(["0", "1", "2", "3+"], size=n_samples, p=[0.57, 0.17, 0.16, 0.10])
    education = np.random.choice(["Graduate", "Not Graduate"], size=n_samples, p=[0.79, 0.21])
    self_employed = np.random.choice(["No", "Yes"], size=n_samples, p=[0.86, 0.14])
    property_area = np.random.choice(["Semiurban", "Urban", "Rural"], size=n_samples, p=[0.38, 0.33, 0.29])

    # Incomes & Loan Amounts (Lognormal distributions)
    applicant_income = np.random.lognormal(mean=8.6, sigma=0.5, size=n_samples).astype(int) + 1500
    coapplicant_has = np.random.choice([0, 1], size=n_samples, p=[0.45, 0.55])
    coapplicant_income = (np.random.lognormal(mean=7.9, sigma=0.6, size=n_samples) * coapplicant_has).astype(int)

    # Credit scores (300 to 850)
    credit_scores = np.random.normal(loc=680, scale=75, size=n_samples).clip(300, 850).astype(int)
    credit_history = np.where(credit_scores >= 620, 1.0, 0.0)
    # Inject 5% credit noise
    noise_mask = np.random.rand(n_samples) < 0.05
    credit_history[noise_mask] = 1.0 - credit_history[noise_mask]

    # Loan amounts in thousands ($20k to $500k)
    total_inc = applicant_income + coapplicant_income
    loan_amount = np.clip((total_inc * np.random.uniform(0.015, 0.045, size=n_samples)).astype(int), 20, 500)
    loan_term = np.random.choice([120, 180, 240, 360, 480], size=n_samples, p=[0.05, 0.08, 0.07, 0.75, 0.05])

    # Calculate Balanced Loan Approval Score
    loan_to_income = loan_amount / ((total_inc / 1000.0) + 1e-5)
    
    score = (
        (credit_history * 2.5) +
        ((credit_scores - 650) / 60.0) +
        np.where(loan_to_income < 3.0, 1.5, -1.5) +
        np.where(education == "Graduate", 0.5, 0.0) +
        np.where(property_area == "Semiurban", 0.5, 0.0) +
        np.random.normal(0, 0.8, n_samples)
    )
    
    prob_approval = 1.0 / (1.0 + np.exp(-score))
    loan_status = np.where(prob_approval >= 0.5, "Y", "N")

    # Create DataFrame
    df = pd.DataFrame({
        "Loan_ID": loan_ids,
        "Gender": genders,
        "Married": married,
        "Dependents": dependents,
        "Education": education,
        "Self_Employed": self_employed,
        "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income,
        "LoanAmount": loan_amount,
        "Loan_Amount_Term": loan_term,
        "Credit_History": credit_history,
        "Credit_Score": credit_scores,
        "Property_Area": property_area,
        "Loan_Status": loan_status
    })

    # Introduce realistic missing values (~2% to 3%)
    for col in ["Gender", "Married", "Dependents", "Self_Employed", "LoanAmount", "Loan_Amount_Term", "Credit_History"]:
        mask = np.random.rand(n_samples) < 0.02
        df.loc[mask, col] = np.nan

    return df


def clean_loan_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleans raw loan dataset: handles data types, standardizes categorical values,
    validates numeric constraints.
    """
    cleaned_df = df.copy()
    
    # Strip whitespace from string columns
    str_cols = cleaned_df.select_dtypes(include=["object"]).columns
    for col in str_cols:
        cleaned_df[col] = cleaned_df[col].astype(str).str.strip()
        cleaned_df[col] = cleaned_df[col].replace(["nan", "None", "NaN", ""], np.nan)

    # Ensure numeric types
    num_cols = ["ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term", "Credit_History", "Credit_Score"]
    for col in num_cols:
        if col in cleaned_df.columns:
            cleaned_df[col] = pd.to_numeric(cleaned_df[col], errors="coerce")

    return cleaned_df


def load_and_save_data(raw_data_path: str = "data/raw/loan_data.csv",
                      processed_data_path: str = "data/processed/cleaned_loan_data.csv") -> pd.DataFrame:
    """
    Generates or loads raw dataset, applies cleaning, and saves processed CSV.
    """
    os.makedirs(os.path.dirname(raw_data_path), exist_ok=True)
    os.makedirs(os.path.dirname(processed_data_path), exist_ok=True)

    df_raw = generate_raw_loan_dataset()
    df_raw.to_csv(raw_data_path, index=False)
    print(f"Generated raw dataset at {raw_data_path}")

    df_cleaned = clean_loan_dataset(df_raw)
    df_cleaned.to_csv(processed_data_path, index=False)
    print(f"Saved cleaned dataset at {processed_data_path}")
    return df_cleaned


if __name__ == "__main__":
    df = load_and_save_data()
    print("Class distribution:\n", df["Loan_Status"].value_counts())
