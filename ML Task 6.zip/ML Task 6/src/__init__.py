"""
SmartLoan AI Package
Production Machine Learning Pipeline for Loan Approval Prediction & Financial Risk Assessment.
"""

__version__ = "1.0.0"
