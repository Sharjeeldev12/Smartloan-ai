import os
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Wedge

def create_mock_screenshots():
    os.makedirs("reports/screenshots", exist_ok=True)
    
    # 1. Dashboard Single Predictor Mock Screenshot
    fig, ax = plt.subplots(figsize=(10, 6), facecolor="#0f172a")
    ax.set_facecolor("#1e293b")
    ax.text(0.5, 0.85, "SmartLoan AI -- Financial Risk & Approval Engine", fontsize=16, fontweight="bold", color="#38bdf8", ha="center")
    ax.text(0.5, 0.73, "Single Applicant Evaluation Module", fontsize=12, color="#94a3b8", ha="center")
    
    # Draw Status Box
    ax.add_patch(Rectangle((0.15, 0.35), 0.3, 0.25, color="#10b981", alpha=0.2, ec="#10b981", lw=2))
    ax.text(0.3, 0.47, "APPROVED", fontsize=18, fontweight="bold", color="#34d399", ha="center")
    ax.text(0.3, 0.39, "LOW RISK (98.9%)", fontsize=12, fontweight="bold", color="#38bdf8", ha="center")
    
    # Draw Gauge Representation
    ax.add_patch(Circle((0.7, 0.45), 0.18, color="#334155"))
    ax.add_patch(Wedge((0.7, 0.45), 0.18, 0, 160, color="#10b981"))
    ax.text(0.7, 0.43, "98.9%", fontsize=16, fontweight="bold", color="#ffffff", ha="center")
    ax.text(0.7, 0.22, "Approval Probability Gauge", fontsize=10, color="#94a3b8", ha="center")
    
    ax.axis("off")
    plt.tight_layout()
    plt.savefig("reports/screenshots/dashboard_single.png", dpi=300)
    plt.close()
    print("Created reports/screenshots/dashboard_single.png")

    # 2. Dashboard Batch Mock Screenshot
    fig, ax = plt.subplots(figsize=(10, 6), facecolor="#0f172a")
    ax.set_facecolor("#1e293b")
    ax.text(0.5, 0.85, "Batch Application Processing Engine", fontsize=16, fontweight="bold", color="#38bdf8", ha="center")
    
    # Draw KPI cards
    kpis = [("Total Processed", "500"), ("Approved", "390 (78.0%)"), ("Rejected", "110 (22.0%)"), ("Avg Prob", "82.5%")]
    for i, (label, val) in enumerate(kpis):
        x = 0.1 + i*0.21
        ax.add_patch(Rectangle((x, 0.52), 0.18, 0.18, color="#0f172a", ec="#334155", lw=1.5))
        ax.text(x+0.09, 0.63, val, fontsize=12, fontweight="bold", color="#10b981" if "Approved" in label or "Total" in label else "#38bdf8", ha="center")
        ax.text(x+0.09, 0.55, label, fontsize=8, color="#94a3b8", ha="center")

    ax.text(0.5, 0.35, "Bulk CSV Upload & Export Table Active", fontsize=12, color="#f8fafc", ha="center")
    ax.axis("off")
    plt.tight_layout()
    plt.savefig("reports/screenshots/dashboard_batch.png", dpi=300)
    plt.close()
    print("Created reports/screenshots/dashboard_batch.png")

    # 3. API Swagger Mock Screenshot
    fig, ax = plt.subplots(figsize=(10, 6), facecolor="#1b1b1b")
    ax.set_facecolor("#2d2d2d")
    ax.text(0.5, 0.85, "SmartLoan AI -- FastAPI Interactive OpenAPI Docs", fontsize=16, fontweight="bold", color="#61afef", ha="center")
    
    endpoints = [
        ("GET", "/health", "Service Health Check & Model Version"),
        ("POST", "/predict", "Single Loan Applicant Risk Scoring"),
        ("POST", "/predict_batch", "Bulk CSV/JSON Application Processing"),
        ("GET", "/model_info", "Model Architecture & Evaluation Metrics")
    ]

    for i, (method, ep, desc) in enumerate(endpoints):
        y = 0.65 - i*0.14
        ax.add_patch(Rectangle((0.1, y), 0.12, 0.08, color="#49cc90" if method=="GET" else "#fca130"))
        ax.text(0.16, y+0.025, method, fontsize=10, fontweight="bold", color="#ffffff", ha="center")
        ax.text(0.25, y+0.025, ep, fontsize=12, fontweight="bold", color="#ffffff", ha="left")
        ax.text(0.55, y+0.025, desc, fontsize=10, color="#abb2bf", ha="left")

    ax.axis("off")
    plt.tight_layout()
    plt.savefig("reports/screenshots/api_swagger.png", dpi=300)
    plt.close()
    print("Created reports/screenshots/api_swagger.png")


if __name__ == "__main__":
    create_mock_screenshots()
