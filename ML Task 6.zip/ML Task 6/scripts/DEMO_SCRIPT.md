# SmartLoan AI — Short Video Demo Guide (3–5 Minutes)

This document provides a step-by-step presentation script to record a professional **3–5 minute video demonstration** of **SmartLoan AI** in VS Code.

---

## Video Setup & Preparation
1. Open VS Code with the workspace `e:\ML Task 6`.
2. Open terminal in VS Code (`Ctrl + ~`).
3. Ensure your screen recorder is active (capturing VS Code + browser windows).

---

## Video Script Breakdown

### ⏱️ 0:00 - 0:45 | Project Overview & Architecture
- **Narrative**: *"Hello everyone! Welcome to the demonstration of SmartLoan AI — a production-ready Machine Learning solution for Loan Approval Prediction and Financial Risk Assessment."*
- **Action**:
  - Show the `README.md` file in VS Code.
  - Highlight the project directory structure (`src/`, `api/`, `app/`, `models/`, `tests/`).
  - Explain the end-to-end pipeline architecture: Synthetic & cleaned data ingestion, custom financial feature engineering (DTI ratio, EMI, Credit Tiers), multi-model benchmarking (Logistic Regression, Random Forest, XGBoost), hyperparameter tuning via 5-Fold Stratified CV, FastAPI REST API, and Streamlit Dashboard.

### ⏱️ 0:45 - 1:45 | Data Pipeline & Model Training Execution
- **Narrative**: *"Let's trigger the complete automated training and evaluation pipeline using our master orchestrator script `run_all.py`."*
- **Action**:
  - Run terminal command:
    ```bash
    python run_all.py
    ```
  - Point out the terminal output:
    1. Data generation & cleaning saved to `data/processed/cleaned_loan_data.csv`.
    2. Feature engineering & ColumnTransformer execution.
    3. Stratified Cross-Validation scores across candidate models.
    4. Hyperparameter tuning using `GridSearchCV`.
    5. Serialization of the best model pipeline to `models/best_loan_model.joblib`.
    6. Evaluation metrics computation (Accuracy, F1, ROC-AUC) and chart generation (`confusion_matrix.png`, `roc_curve.png`).
    7. Automated Pytest suite passing 100%.

### ⏱️ 1:45 - 2:45 | REST API Microservice (FastAPI + Swagger UI)
- **Narrative**: *"Next, let's explore our production REST API built with FastAPI."*
- **Action**:
  - Start the API server in terminal:
    ```bash
    uvicorn api.main:app --reload --port 8000
    ```
  - Open browser to `http://localhost:8000/docs`.
  - Demonstrate `/health` endpoint (returns model loaded status and metrics).
  - Execute a sample POST request on `/predict` endpoint:
    - Input applicant JSON payload (Credit score: 740, Income: $6,500, Loan: $180k).
    - Show real-time JSON response: `{"status": "APPROVED", "approval_probability": 0.884, "risk_level": "LOW RISK"}`.

### ⏱️ 2:45 - 4:15 | Streamlit Interactive Prediction Dashboard
- **Narrative**: *"Now let's launch our interactive prediction dashboard."*
- **Action**:
  - In a new terminal tab, run:
    ```bash
    streamlit run app/app.py
    ```
  - Navigate to browser at `http://localhost:8501`.
  - **Tab 1 (Single Applicant Scoring)**: Adjust sliders (Income, Credit Score, Loan Amount) and click *Evaluate Loan Application*. Show the real-time Plotly risk gauge, decision badge, and automated financial warning flags.
  - **Tab 2 (Batch Processing)**: Upload sample CSV file, click *Score Uploaded Batch*, show instant KPI cards and downloadable scored results CSV.
  - **Tab 3 (Model Analytics)**: Show live confusion matrix, ROC-AUC curve, and top feature importance chart.
  - **Tab 4 (EDA)**: Briefly show interactive credit score vs approval scatter plot.

### ⏱️ 4:15 - 5:00 | Codebase Quality & Conclusion
- **Narrative**: *"To conclude, SmartLoan AI features clean modular code, full Docker containerization, comprehensive Pytest coverage, and a Git repository with clean commit history. Thank you!"*
- **Action**:
  - Show `docker-compose.yml` and `git log --oneline` in terminal.
  - End recording.
