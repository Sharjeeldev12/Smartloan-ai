from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class LoanApplicantRequest(BaseModel):
    Gender: str = Field(default="Male", description="Applicant gender: Male, Female")
    Married: str = Field(default="Yes", description="Marital status: Yes, No")
    Dependents: str = Field(default="0", description="Number of dependents: 0, 1, 2, 3+")
    Education: str = Field(default="Graduate", description="Education level: Graduate, Not Graduate")
    Self_Employed: str = Field(default="No", description="Self-employed status: Yes, No")
    ApplicantIncome: float = Field(default=5000.0, ge=0.0, description="Applicant primary annual/monthly income ($)")
    CoapplicantIncome: float = Field(default=1500.0, ge=0.0, description="Co-applicant income ($)")
    LoanAmount: float = Field(default=150.0, gt=0.0, description="Requested loan amount in thousands ($)")
    Loan_Amount_Term: float = Field(default=360.0, gt=0.0, description="Loan term duration in months")
    Credit_History: float = Field(default=1.0, description="Credit history flag: 1.0 (good), 0.0 (poor)")
    Credit_Score: float = Field(default=720.0, ge=300.0, le=850.0, description="Numerical credit score (300 to 850)")
    Property_Area: str = Field(default="Semiurban", description="Property location area: Urban, Semiurban, Rural")

    model_config = {
        "json_schema_extra": {
            "example": {
                "Gender": "Male",
                "Married": "Yes",
                "Dependents": "1",
                "Education": "Graduate",
                "Self_Employed": "No",
                "ApplicantIncome": 6500.0,
                "CoapplicantIncome": 2000.0,
                "LoanAmount": 180.0,
                "Loan_Amount_Term": 360.0,
                "Credit_History": 1.0,
                "Credit_Score": 735.0,
                "Property_Area": "Semiurban"
            }
        }
    }


class PredictionResultResponse(BaseModel):
    prediction: int = Field(..., description="0 for Rejected, 1 for Approved")
    status: str = Field(..., description="APPROVED or REJECTED")
    approval_probability: float = Field(..., description="Estimated probability score (0.0 to 1.0)")
    risk_level: str = Field(..., description="Risk tier: LOW RISK, MODERATE RISK, HIGH RISK, VERY HIGH RISK")


class BatchPredictionRequest(BaseModel):
    applicants: List[LoanApplicantRequest]


class BatchPredictionResponse(BaseModel):
    total_processed: int
    predictions: List[PredictionResultResponse]


class HealthCheckResponse(BaseModel):
    status: str
    model_loaded: bool
    model_name: Optional[str] = None
    version: str
