"""
SmartLoan AI REST API Package
FastAPI application for loan approval predictions and risk assessments.
"""
