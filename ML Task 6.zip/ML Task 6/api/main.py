import os
import json
import pandas as pd
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from api.schemas import (
    LoanApplicantRequest, PredictionResultResponse,
    BatchPredictionRequest, BatchPredictionResponse,
    HealthCheckResponse
)
from src.predict import LoanPredictor

# Global Predictor Instance
predictor = None
metadata = None

def load_model_artifact():
    global predictor, metadata
    model_path = "models/best_loan_model.joblib"
    metadata_path = "models/model_metadata.json"

    if os.path.exists(model_path):
        try:
            predictor = LoanPredictor(model_path)
            print(f"Loaded LoanPredictor from {model_path}")
        except Exception as e:
            print(f"Error loading model: {e}")

    if os.path.exists(metadata_path):
        with open(metadata_path, "r") as f:
            metadata = json.load(f)

# Load model artifact at startup
load_model_artifact()

@asynccontextmanager
async def lifespan(app: FastAPI):
    load_model_artifact()
    yield

app = FastAPI(
    title="SmartLoan AI — Production Loan Approval & Risk Assessment API",
    description="Enterprise REST API for evaluating loan application risks, predicting credit approval status, and returning probability scores.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Enable CORS for frontend Streamlit / external clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", tags=["Overview"])
def root_overview():
    return {
        "service": "SmartLoan AI REST API",
        "status": "Online",
        "documentation": "/docs",
        "health_check": "/health"
    }


@app.get("/health", response_model=HealthCheckResponse, tags=["Health"])
def health_check():
    model_loaded = predictor is not None
    model_name = metadata.get("model_name", "Unknown") if metadata else None
    return HealthCheckResponse(
        status="healthy" if model_loaded else "unhealthy",
        model_loaded=model_loaded,
        model_name=model_name,
        version="1.0.0"
    )


@app.post("/predict", response_model=PredictionResultResponse, tags=["Inference"])
def predict_single_applicant(request: LoanApplicantRequest):
    if predictor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model artifact is not loaded. Train the model first."
        )

    try:
        data_dict = request.model_dump()
        result = predictor.predict_single(data_dict)
        return PredictionResultResponse(**result)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Prediction error: {str(e)}"
        )


@app.post("/predict_batch", response_model=BatchPredictionResponse, tags=["Inference"])
def predict_batch_applicants(request: BatchPredictionRequest):
    if predictor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model artifact is not loaded. Train the model first."
        )

    try:
        data_dicts = [a.model_dump() for a in request.applicants]
        df = pd.DataFrame(data_dicts)
        df_scored = predictor.predict_batch(df)

        results = []
        for idx, row in df_scored.iterrows():
            results.append(PredictionResultResponse(
                prediction=1 if row["Predicted_Status"] == "APPROVED" else 0,
                status=row["Predicted_Status"],
                approval_probability=float(row["Approval_Probability"]),
                risk_level=row["Risk_Level"]
            ))

        return BatchPredictionResponse(
            total_processed=len(results),
            predictions=results
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch prediction error: {str(e)}"
        )


@app.get("/model_info", tags=["Metadata"])
def get_model_information():
    if metadata is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Model metadata not found."
        )
    return metadata
