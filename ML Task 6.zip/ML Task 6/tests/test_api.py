import os
import pytest
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_api_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["service"] == "SmartLoan AI REST API"


def test_api_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert "status" in response.json()


def test_api_predict():
    payload = {
        "Gender": "Male",
        "Married": "Yes",
        "Dependents": "1",
        "Education": "Graduate",
        "Self_Employed": "No",
        "ApplicantIncome": 7000.0,
        "CoapplicantIncome": 2500.0,
        "LoanAmount": 160.0,
        "Loan_Amount_Term": 360.0,
        "Credit_History": 1.0,
        "Credit_Score": 740.0,
        "Property_Area": "Semiurban"
    }
    response = client.post("/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "prediction" in data
    assert "status" in data
    assert "approval_probability" in data
    assert "risk_level" in data
