import os
import pytest
import pandas as pd
from src.data_loader import generate_raw_loan_dataset
from src.train import train_and_evaluate_models
from src.predict import LoanPredictor

def test_model_training_and_serialization():
    # Execute training workflow
    pipeline, X_tr, X_te, y_tr, y_te, metadata = train_and_evaluate_models()

    assert os.path.exists("models/best_loan_model.joblib")
    assert os.path.exists("models/model_metadata.json")
    assert metadata["best_cv_roc_auc"] > 0.50


def test_loan_predictor_inference():
    predictor = LoanPredictor("models/best_loan_model.joblib")
    sample_applicant = {
        "Gender": "Male",
        "Married": "Yes",
        "Dependents": "0",
        "Education": "Graduate",
        "Self_Employed": "No",
        "ApplicantIncome": 6000,
        "CoapplicantIncome": 2000,
        "LoanAmount": 120,
        "Loan_Amount_Term": 360,
        "Credit_History": 1.0,
        "Credit_Score": 750,
        "Property_Area": "Semiurban"
    }

    result = predictor.predict_single(sample_applicant)
    assert result["prediction"] in [0, 1]
    assert result["status"] in ["APPROVED", "REJECTED"]
    assert 0.0 <= result["approval_probability"] <= 1.0
    assert result["risk_level"] in ["LOW RISK", "MODERATE RISK", "HIGH RISK", "VERY HIGH RISK"]
