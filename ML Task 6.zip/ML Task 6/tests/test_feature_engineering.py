import pytest
import pandas as pd
import numpy as np
from src.feature_engineering import FinancialFeatureTransformer, add_engineered_features

def test_financial_feature_transformer():
    sample_df = pd.DataFrame([{
        "ApplicantIncome": 5000,
        "CoapplicantIncome": 2000,
        "LoanAmount": 150,
        "Loan_Amount_Term": 360,
        "Credit_Score": 720
    }])

    transformer = FinancialFeatureTransformer()
    transformed = transformer.transform(sample_df)

    assert "Total_Income" in transformed.columns
    assert "Debt_to_Income_Ratio" in transformed.columns
    assert "Monthly_EMI" in transformed.columns
    assert "Balance_Income" in transformed.columns
    assert "Credit_Tier" in transformed.columns
    assert "Log_Total_Income" in transformed.columns

    assert transformed["Total_Income"].iloc[0] == 7000
    assert transformed["Credit_Tier"].iloc[0] == "Good"


def test_helper_add_engineered_features():
    sample_df = pd.DataFrame([{
        "ApplicantIncome": 3000,
        "CoapplicantIncome": 0,
        "LoanAmount": 100,
        "Loan_Amount_Term": 180,
        "Credit_Score": 520
    }])

    transformed = add_engineered_features(sample_df)
    assert transformed["Credit_Tier"].iloc[0] == "Poor"
