import os
import sys
import json
import pandas as pd
import numpy as np
import streamlit as st
from PIL import Image

# Ensure project root is in path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.predict import LoanPredictor
from app.utils import create_risk_gauge_chart, get_financial_warning_flags

# -----------------------------------------------------------------------------
# Streamlit Page Config & Custom Styling
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="SmartLoan AI — Loan Approval & Risk Assessment",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    /* Dark Modern Theme */
    .stApp {
        background-color: #0f172a;
        color: #f8fafc;
    }
    .main-header {
        font-size: 2.2rem;
        font-weight: 800;
        background: linear-gradient(90deg, #3b82f6, #10b981);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        color: #94a3b8;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: #1e293b;
        border: 1px solid #334155;
        padding: 1.2rem;
        border-radius: 12px;
        text-align: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
    }
    .status-approved {
        background: rgba(16, 185, 129, 0.15);
        border: 2px solid #10b981;
        color: #34d399;
        font-size: 1.6rem;
        font-weight: bold;
        padding: 0.8rem;
        border-radius: 10px;
        text-align: center;
    }
    .status-rejected {
        background: rgba(239, 68, 68, 0.15);
        border: 2px solid #ef4444;
        color: #f87171;
        font-size: 1.6rem;
        font-weight: bold;
        padding: 0.8rem;
        border-radius: 10px;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# Helper Function to Load Model Engine
# -----------------------------------------------------------------------------
@st.cache_resource
def load_prediction_engine():
    model_path = "models/best_loan_model.joblib"
    if not os.path.exists(model_path):
        return None
    try:
        return LoanPredictor(model_path)
    except Exception as e:
        st.error(f"Error loading model pipeline: {e}")
        return None

predictor = load_prediction_engine()

# -----------------------------------------------------------------------------
# Sidebar Navigation & Information
# -----------------------------------------------------------------------------
with st.sidebar:
    st.image("https://img.icons8.com/isometric/100/bank-building.png", width=70)
    st.markdown("<h2 style='color:#38bdf8;'>SmartLoan AI</h2>", unsafe_allow_html=True)
    st.markdown("Production Credit Scoring & Risk Engine")
    st.divider()

    st.markdown("### System Status")
    if predictor:
        st.success("🟢 Model Engine Active")
    else:
        st.warning("⚠️ Model Artifact Missing")
        st.info("Run `python run_all.py` to train and serialize model.")

    if os.path.exists("models/model_metadata.json"):
        with open("models/model_metadata.json") as f:
            meta = json.load(f)
        st.markdown(f"**Model**: {meta.get('model_name', 'Ensemble')}")
        st.markdown(f"**CV ROC-AUC**: `{meta.get('best_cv_roc_auc', 0.0):.4f}`")

    st.divider()
    st.markdown("### REST API Endpoint")
    st.code("http://localhost:8000/docs", language="text")
    st.caption("FastAPI OpenAPI Swagger Documentation")

# -----------------------------------------------------------------------------
# Main Header
# -----------------------------------------------------------------------------
st.markdown("<div class='main-header'>SmartLoan AI — Financial Risk & Approval Engine</div>", unsafe_allow_html=True)
st.markdown("<div class='sub-header'>Real-time Automated Credit Decisioning, Batch Risk Scoring & Model Explainability</div>", unsafe_allow_html=True)

# Main Tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "🎯 Single Applicant Scoring",
    "📁 Batch CSV Processing",
    "📊 Model Analytics & Metrics",
    "🔍 Exploratory Data Analysis"
])

# =============================================================================
# TAB 1: SINGLE APPLICANT SCORING
# =============================================================================
with tab1:
    st.subheader("Loan Applicant Financial Profile")
    
    col_input1, col_input2, col_input3 = st.columns(3)
    
    with col_input1:
        st.markdown("#### Demographics & Employment")
        gender = st.selectbox("Gender", ["Male", "Female"])
        married = st.selectbox("Marital Status", ["Yes", "No"])
        dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
        education = st.selectbox("Education Level", ["Graduate", "Not Graduate"])
        self_employed = st.selectbox("Self Employed", ["No", "Yes"])

    with col_input2:
        st.markdown("#### Financial Indicators")
        applicant_inc = st.number_input("Applicant Income ($/yr)", min_value=0, max_value=200000, value=5500, step=500)
        coapplicant_inc = st.number_input("Coapplicant Income ($/yr)", min_value=0, max_value=100000, value=1500, step=500)
        loan_amount = st.number_input("Loan Amount ($ in thousands)", min_value=10, max_value=1000, value=150, step=10)
        loan_term = st.selectbox("Loan Term (Months)", [120, 180, 240, 360, 480], index=3)

    with col_input3:
        st.markdown("#### Credit & Property Profile")
        credit_history = st.selectbox("Credit History Clean?", [1.0, 0.0], format_func=lambda x: "Yes (1.0)" if x == 1.0 else "No (0.0)")
        credit_score = st.slider("Credit Score (FICO)", min_value=300, max_value=850, value=720, step=5)
        property_area = st.selectbox("Property Location Area", ["Semiurban", "Urban", "Rural"])

    st.markdown("---")
    
    predict_btn = st.button("🚀 Evaluate Loan Application", type="primary", use_container_width=True)

    if predict_btn:
        if predictor is None:
            st.error("Model engine is missing! Please execute `python run_all.py` first.")
        else:
            applicant_data = {
                "Gender": gender,
                "Married": married,
                "Dependents": dependents,
                "Education": education,
                "Self_Employed": self_employed,
                "ApplicantIncome": applicant_inc,
                "CoapplicantIncome": coapplicant_inc,
                "LoanAmount": loan_amount,
                "Loan_Amount_Term": loan_term,
                "Credit_History": credit_history,
                "Credit_Score": credit_score,
                "Property_Area": property_area
            }

            res = predictor.predict_single(applicant_data)
            
            st.markdown("### Risk Evaluation Results")
            res_col1, res_col2, res_col3 = st.columns([1.2, 1.5, 1.3])

            with res_col1:
                st.markdown("#### Approval Decision")
                if res["status"] == "APPROVED":
                    st.markdown("<div class='status-approved'>✅ APPROVED</div>", unsafe_allow_html=True)
                else:
                    st.markdown("<div class='status-rejected'>❌ REJECTED</div>", unsafe_allow_html=True)

                st.markdown(f"<h3 style='text-align:center; color:#38bdf8;'>Risk Tier: {res['risk_level']}</h3>", unsafe_allow_html=True)

            with res_col2:
                fig_gauge = create_risk_gauge_chart(res["approval_probability"])
                st.plotly_chart(fig_gauge, use_container_width=True)

            with res_col3:
                st.markdown("#### Automated Risk Flags")
                flags = get_financial_warning_flags(applicant_data)
                for f in flags:
                    st.markdown(f)

# =============================================================================
# TAB 2: BATCH CSV PROCESSING
# =============================================================================
with tab2:
    st.subheader("Bulk Loan Applications Scoring Engine")
    st.markdown("Upload a CSV file containing multiple loan applicants to perform instant batch risk scoring.")

    uploaded_file = st.file_uploader("Upload Applicants CSV File", type=["csv"])

    if uploaded_file is not None:
        try:
            df_upload = pd.read_csv(uploaded_file)
            st.markdown(f"**Uploaded Dataset Preview ({len(df_upload)} records):**")
            st.dataframe(df_upload.head(5), use_container_width=True)

            if st.button("⚡ Score Uploaded Batch", type="primary"):
                if predictor is None:
                    st.error("Model engine missing. Train model first.")
                else:
                    with st.spinner("Processing batch predictions..."):
                        df_scored = predictor.predict_batch(df_upload)

                    st.success("Batch scoring completed successfully!")

                    # Summary Metrics
                    b_col1, b_col2, b_col3, b_col4 = st.columns(4)
                    tot = len(df_scored)
                    app_count = (df_scored["Predicted_Status"] == "APPROVED").sum()
                    rej_count = (df_scored["Predicted_Status"] == "REJECTED").sum()
                    avg_prob = df_scored["Approval_Probability"].mean() * 100

                    b_col1.metric("Total Applicants", tot)
                    b_col2.metric("Approved Count", app_count, delta=f"{(app_count/tot)*100:.1f}%")
                    b_col3.metric("Rejected Count", rej_count, delta=f"-{(rej_count/tot)*100:.1f}%")
                    b_col4.metric("Mean Approval Probability", f"{avg_prob:.1f}%")

                    st.markdown("#### Scored Dataset")
                    st.dataframe(df_scored, use_container_width=True)

                    # Download button
                    csv_bytes = df_scored.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="📥 Download Scored Batch Results CSV",
                        data=csv_bytes,
                        file_name="scored_loan_predictions.csv",
                        mime="text/csv"
                    )
        except Exception as e:
            st.error(f"Error processing uploaded CSV: {e}")
    else:
        st.info("💡 Sample format requires standard loan columns: Gender, Married, Dependents, Education, Self_Employed, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, Credit_History, Credit_Score, Property_Area.")

# =============================================================================
# TAB 3: MODEL PERFORMANCE ANALYTICS
# =============================================================================
with tab3:
    st.subheader("Model Validation & Performance Visualizations")

    if os.path.exists("reports/metrics.json"):
        with open("reports/metrics.json") as f:
            m = json.load(f)

        m_col1, m_col2, m_col3, m_col4, m_col5 = st.columns(5)
        m_col1.metric("Accuracy Score", f"{m['accuracy']*100:.1f}%")
        m_col2.metric("Precision", f"{m['precision']*100:.1f}%")
        m_col3.metric("Recall", f"{m['recall']*100:.1f}%")
        m_col4.metric("F1 Score", f"{m['f1_score']*100:.1f}%")
        m_col5.metric("ROC-AUC", f"{m['roc_auc']:.4f}")

    st.markdown("---")
    img_col1, img_col2 = st.columns(2)

    with img_col1:
        st.markdown("#### Confusion Matrix")
        if os.path.exists("reports/confusion_matrix.png"):
            st.image("reports/confusion_matrix.png", use_column_width=True)
        else:
            st.info("Confusion matrix plot unavailable.")

    with img_col2:
        st.markdown("#### Receiver Operating Characteristic (ROC) Curve")
        if os.path.exists("reports/roc_curve.png"):
            st.image("reports/roc_curve.png", use_column_width=True)
        else:
            st.info("ROC curve plot unavailable.")

    st.markdown("---")
    st.markdown("#### Top Feature Importances")
    if os.path.exists("reports/feature_importance.png"):
        st.image("reports/feature_importance.png", use_column_width=True)

# =============================================================================
# TAB 4: EXPLORATORY DATA ANALYSIS
# =============================================================================
with tab4:
    st.subheader("Exploratory Data Insights")

    data_path = "data/processed/cleaned_loan_data.csv"
    if os.path.exists(data_path):
        df_eda = pd.read_csv(data_path)

        st.markdown("#### Dataset Overview")
        st.dataframe(df_eda.describe(), use_container_width=True)

        eda_col1, eda_col2 = st.columns(2)

        with eda_col1:
            st.markdown("##### Approval Rate by Property Area")
            prop_df = df_eda.groupby(["Property_Area", "Loan_Status"]).size().unstack().fillna(0)
            st.bar_chart(prop_df)

        with eda_col2:
            st.markdown("##### Credit Score vs Loan Approval")
            st.scatter_chart(data=df_eda, x="Credit_Score", y="LoanAmount", color="Loan_Status")
    else:
        st.info("Cleaned dataset unavailable for EDA. Run `python run_all.py`.")
