import plotly.graph_objects as go
import pandas as pd

def create_risk_gauge_chart(probability: float) -> go.Figure:
    """
    Renders an interactive Plotly gauge chart displaying approval probability and risk level.
    """
    prob_percent = float(probability * 100)

    if prob_percent >= 75:
        bar_color = "#10b981"  # Emerald Green
    elif prob_percent >= 50:
        bar_color = "#3b82f6"  # Blue
    elif prob_percent >= 30:
        bar_color = "#f59e0b"  # Amber
    else:
        bar_color = "#ef4444"  # Red

    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=prob_percent,
        domain={'x': [0, 1], 'y': [0, 1]},
        number={'suffix': "%", 'font': {'size': 36, 'color': bar_color}},
        title={'text': "Approval Probability Score", 'font': {'size': 18, 'color': "#ffffff"}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#475569"},
            'bar': {'color': bar_color, 'thickness': 0.3},
            'bgcolor': "#1e293b",
            'borderwidth': 2,
            'bordercolor': "#334155",
            'steps': [
                {'range': [0, 30], 'color': 'rgba(239, 68, 68, 0.2)'},
                {'range': [30, 50], 'color': 'rgba(245, 158, 11, 0.2)'},
                {'range': [50, 75], 'color': 'rgba(59, 130, 246, 0.2)'},
                {'range': [75, 100], 'color': 'rgba(16, 185, 129, 0.2)'}
            ],
            'threshold': {
                'line': {'color': "#ffffff", 'width': 3},
                'thickness': 0.8,
                'value': prob_percent
            }
        }
    ))

    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={'color': "#ffffff"},
        height=260,
        margin=dict(l=20, r=20, t=40, b=20)
    )
    return fig


def get_financial_warning_flags(applicant: dict) -> list:
    """
    Analyzes applicant fields and returns key risk warning flags.
    """
    flags = []
    tot_income = applicant.get("ApplicantIncome", 0) + applicant.get("CoapplicantIncome", 0)
    loan_amt_k = applicant.get("LoanAmount", 0) * 1000
    term = applicant.get("Loan_Amount_Term", 360)
    credit_hist = applicant.get("Credit_History", 1.0)
    credit_score = applicant.get("Credit_Score", 650)

    if credit_hist == 0.0 or credit_score < 580:
        flags.append("🚨 **Low Credit Score / Adverse Credit History**: Significant risk factor.")

    if tot_income > 0:
        dti = loan_amt_k / tot_income
        if dti > 3.5:
            flags.append(f"⚠️ **High Debt-to-Income Ratio ({dti:.2f})**: Loan amount requested exceeds 3.5x annual income.")

    monthly_income = tot_income / 12.0
    monthly_emi = loan_amt_k / (term if term > 0 else 360)
    if monthly_income > 0 and (monthly_emi / monthly_income) > 0.45:
        flags.append(f"⚠️ **High Debt Service Burden**: Estimated EMI (${monthly_emi:.0f}/mo) exceeds 45% of monthly income.")

    if not flags:
        flags.append("✅ **Healthy Financial Profile**: No major risk indicators detected.")

    return flags
