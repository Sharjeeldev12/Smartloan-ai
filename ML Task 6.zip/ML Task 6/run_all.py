import os
import sys
import subprocess

from src.data_loader import load_and_save_data
from src.train import train_and_evaluate_models
from src.evaluate import evaluate_model_pipeline
from notebooks.create_notebook import create_eda_notebook
from scripts.generate_screenshots import create_mock_screenshots

def run_pipeline():
    print("SmartLoan AI -- Master Pipeline Execution & Verification")

    # Step 1: Data Generation & Ingestion
    print("\n[Step 1/6] Running Data Collection & Automated Cleaning...")
    load_and_save_data()

    # Step 2: Notebook Generation
    print("\n[Step 2/6] Building Jupyter Exploratory Analysis Notebook...")
    create_eda_notebook()

    # Step 3: Model Training & Hyperparameter Tuning
    print("\n[Step 3/6] Running Cross-Validation & Hyperparameter Tuning...")
    pipeline, X_tr, X_te, y_tr, y_te, metadata = train_and_evaluate_models()

    # Step 4: Model Evaluation & Visual Report Generation
    print("\n[Step 4/6] Computing Evaluation Metrics & Generating Visual Reports...")
    evaluate_model_pipeline(pipeline, X_te, y_te)

    # Step 5: Screenshots Generation
    print("\n[Step 5/6] Generating UI Screenshots for Documentation...")
    create_mock_screenshots()

    # Step 6: Pytest Automated Verification Suite
    print("\n[Step 6/6] Executing Pytest Test Suite...")
    try:
        res = subprocess.run([sys.executable, "-m", "pytest", "tests/", "-v"], capture_output=False)
        returncode = res.returncode
    except Exception as e:
        print(f"Pytest invocation error: {e}")
        returncode = 1
    
    if returncode == 0:
        print("[SUCCESS] Master Pipeline Completed & All Tests Passed!")
        print("Serialized Model: models/best_loan_model.joblib")
        print("Evaluation Reports: reports/")
        print("REST API Command: uvicorn api.main:app --port 8000")
        print("Dashboard Command: streamlit run app/app.py")
        
    else:
        print("\n[WARNING] Test suite reported warnings or non-zero exit code.")


if __name__ == "__main__":
    run_pipeline()
